import compileall
import py_compile
import f321
if __name__ == "__main__":
    print("hello")
    # compileall.compile_dir(r'./')
    #py_compile.compile(r'./n123.py')
    f321.f21.create()