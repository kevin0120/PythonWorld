from setuptools import setup
setup(name='n123',
      version='1.0',
      py_modules=['n123'],
      )